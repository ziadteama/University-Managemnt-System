create definer = root@localhost trigger before_insert_schedules
    before insert
    on schedules
    for each row
BEGIN
    DECLARE user_role ENUM('dr', 'ta');

    -- Get the role of the user based on user_id
    SELECT role INTO user_role
    FROM users
    WHERE user_id = NEW.user_id;

    -- Set class_type based on the role
    IF user_role = 'dr' THEN
        SET NEW.class_type = 'lecture';
    ELSEIF user_role = 'ta' THEN
        SET NEW.class_type = 'tutorial';
    END IF;
END;

